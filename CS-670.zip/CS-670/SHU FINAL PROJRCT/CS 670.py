
from tkinter import messagebox
from tkinter import *
from tkinter import simpledialog
import tkinter as tk
from tkinter import filedialog
import matplotlib.pyplot as plt
from tkinter.filedialog import askopenfilename
from sklearn.naive_bayes import MultinomialNB
from sklearn.naive_bayes import BernoulliNB

#import string
#from nltk.corpus import stopwords

# Create the main window
first_window = tk.Tk()
first_window.title("First Window")
first_window.geometry("1200x500")



global filename
global text

def process_text(text):
    nopunc = [char for char in text if char not in string.punctuation]
    nopunc = ''.join(nopunc)
    clean_words = [word for word in nopunc.split() if word.lower() not in stopwords.words('english')]
    return clean_words

def upload():
    global filename
    filename = filedialog.askdirectory(initialdir=".")
    pathlabel.config(text=filename)
    text.delete('1.0', tk.END)
    text.insert(tk.END, filename + " loaded\n")

def open_second_window():
    first_window.withdraw()
    second_window = tk.Toplevel()
    second_window.title("Second Window")
    second_window.geometry("1200x500")
    
    font = ('times', 16, 'bold')
    title = tk.Label(second_window, text='Spammer Detection and Fake User Identification on Social Networks')
    title.config(bg='brown', fg='white', font=font, height=3, width=120)
    title.place(x=0, y=5)
    
    font1 = ('times', 14, 'bold')
    
    uploadButton = tk.Button(second_window, text="Upload Tweets Dataset", command=upload)
    uploadButton.place(x=50, y=100)
    uploadButton.config(font=font1)

    global text
    text = tk.Text(second_window, height=20, width=150)
    scroll = tk.Scrollbar(text)
    text.configure(yscrollcommand=scroll.set)
    text.place(x=10, y=350)
    text.config(font=font1)

    global pathlabel
    pathlabel = tk.Label(second_window, bg='blue', fg='black', font=font1)
    pathlabel.place(x=470, y=100)

    prev_button = tk.Button(second_window, text="Previous", command=lambda: go_back_to_first(second_window))
    prev_button.pack(side=tk.LEFT, padx=20, pady=20)

    next_button = tk.Button(second_window, text="Next", command=lambda: open_third_window(second_window))
    next_button.pack(side=tk.RIGHT, padx=20, pady=20)





def open_third_window(second_window):
    second_window.withdraw()
    third_window = tk.Toplevel()
    third_window.title("Third Window")
    third_window.geometry("1200x500")
    
    font = ('times', 16, 'bold')
    title = tk.Label(third_window, text='Spammer Detection and Fake User Identification on Social Networks')
    title.config(bg='brown', fg='white', font=font, height=3, width=120)
    title.place(x=0, y=5)
    
   
    

    # Button to return to the second window
    prev_button = tk.Button(third_window, text="Previous", command=lambda: go_back_to_second(third_window))
    prev_button.pack(side=tk.LEFT, padx=20, pady=20)

    next_button = tk.Button(second_window, text="Next", command=lambda: open_fourth_window(third_window))
    next_button.pack(side=tk.RIGHT, padx=20, pady=20)


def go_back_to_first(second_window):
    second_window.destroy()
    first_window.deiconify()

def go_back_to_second(third_window):
    third_window.destroy()
    second_window.deiconify()
    
def naiveBayesAlg():
    global nb_acc
    text.delete('1.0', END)
    cls = BernoulliNB(binarize=0.0)
    cls.fit(X_train, y_train)
    text.insert(END,"Prediction Results\n\n") 
    prediction_data = prediction(X_test, cls)
    nb_acc = cal_accuracy(y_test, prediction_data,'Naive Bayes Algorithm Accuracy')
    precision = precision_score(y_test, prediction_data,average='macro') * 100
    recall = recall_score(y_test, prediction_data,average='macro') * 100
    fmeasure = f1_score(y_test, prediction_data,average='macro') * 100
    text.insert(END,"Naive Bayes Precision : "+str(precision)+"\n")
    text.insert(END,"Naive Bayes Recall : "+str(recall)+"\n")
    text.insert(END,"Naive Bayes FMeasure : "+str(fmeasure)+"\n")



# Add a label to the first window
font = ('times', 16, 'bold')
title = tk.Label(first_window, text='Spammer Detection and Fake User Identification on Social Networks')
title.config(bg='brown', fg='white', font=font, height=3, width=120)
title.place(x=0, y=5)

# Add next button to the first window
next_button = tk.Button(first_window, text="Next", command=open_second_window)
next_button.pack(side=tk.RIGHT, padx=110, pady=20)

# Start the application
first_window.mainloop()
