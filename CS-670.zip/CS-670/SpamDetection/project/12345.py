from tkinter import messagebox
from tkinter import *
from tkinter import simpledialog
import tkinter
from tkinter import filedialog

from tkinter.filedialog import askopenfilename
import json
main = tkinter.Tk()
main.title("SHU Final Project CS670") #designing main screen
main.geometry("1300x1200")
global filename

def upload(): #function to upload tweeter profile
    global filename
    filename = filedialog.askdirectory(initialdir=".")
    pathlabel.config(text=filename)
    text.delete('1.0', END)
    text.insert(END,filename+" loaded\n");


  
    
font = ('times', 16, 'bold')
title = Label(main, text='Spammer Detection and Fake User Identification on TWITTER')
title.config(bg='yellow', fg='black')  
title.config(font=font)           
title.config(height=3, width=120)       
title.place(x=0,y=5)



font1 = ('times', 14, 'bold')
uploadButton = Button(main, text="Upload Twitter JSON Format Tweets Dataset")
uploadButton.place(x=50,y=100)
uploadButton.config(font=font1)  

pathlabel = Label(main)
pathlabel.config(bg='lightblue', fg='black')  
pathlabel.config(font=font1)           
pathlabel.place(x=470,y=100)

fakeButton = Button(main, text="Load Naive Bayes To Analyse Tweet Text or URL")
fakeButton.place(x=50,y=150)
fakeButton.config(font=font1) 

randomButton = Button(main, text="Detect Fake Content, Spam URL, Trending Topic & Fake Account")
randomButton.place(x=520,y=150)
randomButton.config(font=font1) 

detectButton = Button(main, text="Run Random Forest For Fake Account")
detectButton.place(x=50,y=200)
detectButton.config(font=font1) 

exitButton = Button(main, text="Run Extension Extreme Machine Learning Algorithm")
exitButton.place(x=520,y=200)
exitButton.config(font=font1)

nbsButton = Button(main, text="Run Naive Bayes Algorithm")
nbsButton.place(x=50,y=250)
nbsButton.config(font=font1) 

svmButton = Button(main, text="Run SVM Algorithm")
svmButton.place(x=520,y=250)
svmButton.config(font=font1)

detectButton = Button(main, text="Prediction Accuracy Comparison")
detectButton.place(x=50,y=300)
detectButton.config(font=font1) 

exitButton = Button(main, text="Detection Graph")
exitButton.place(x=520,y=300)
exitButton.config(font=font1)



font1 = ('times', 12, 'bold')
text=Text(main,height=20,width=150)
scroll=Scrollbar(text)
text.configure(yscrollcommand=scroll.set)
text.place(x=10,y=350)
text.config(font=font1)


main.config(bg='lightblue')
main.mainloop()
